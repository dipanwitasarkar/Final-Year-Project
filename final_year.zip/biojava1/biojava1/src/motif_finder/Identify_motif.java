package motif_finder;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Identify_motif {
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost:3306/nest_motifdb";

	// Database credentials
	static final String USER = "root";
	static final String PASS = "1234";

	static Connection conn = null;
	static Statement stmt = null;
	static Statement stmt1=null;   
	static Statement stmt2=null;
	
public void Nested_motif(String seq) {
	
				try {
			        // STEP 2: Register JDBC driver
			        Class.forName("com.mysql.jdbc.Driver");

			        // STEP 3: Open a connection
			        //System.out.print("\nConnecting to database...");
			        conn = DriverManager.getConnection(DB_URL, USER, PASS);
			        //System.out.println(" SUCCESS!\n");

			       
			       
			       stmt1 = conn.createStatement();
			        String sql = "INSERT INTO dna(Sequence) " +
			            "VALUES ('"+(seq)+"')";
			        stmt1.executeUpdate(sql);

			        System.out.println("\nSEQUENCE INSERTION SUCCESS!\n");

			   } catch(SQLException se) {
			        se.printStackTrace();
			    } catch(Exception e) {
			        e.printStackTrace();
			    } finally {
			        try {
			            if(stmt1 != null)
			                conn.close();
			           
			        } catch(SQLException se) {
			        }
			        try {
			            if(conn != null)
			                conn.close();
			        } catch(SQLException se) {
			            se.printStackTrace();
			        }
			    }
			    
			
			int len = seq.length(); // total sequence length
			int window_size; // size of the sliding window
			String window; //the actual window
			String coveredMotifs[]; // record of covered motifs of current window size
			int covered; //number of motifs of given length covered
			int flag; //to check if motif is covered
			
			for (window_size = 2; window_size<=len/2;++window_size) {
				// this loop runs through all possible window sizes
				coveredMotifs = new String [len-window_size+1];
				covered=0; 
				int startPoint,endPoint; // the variables to hold the start and end points of the window in the string
				
				for (startPoint=0; startPoint <= len-window_size;++startPoint) {
					//this loop runs through all possible windows of the selected size
					// for repition, the end point can at max be the last character of the sequence, so the start point has to be window_size less than it.
					flag = 0;
					endPoint = startPoint+window_size;
					
					window = seq.substring(startPoint,endPoint); //the window is assigned here
						
					for (int i=0;i<covered;++i){
						if (window.equals(coveredMotifs[i])) {
							
							flag = 1;
							break;
						}
					}
					
					if (flag==0){
						
						coveredMotifs[covered] = window;
						covered++;
						getMotif(window,seq,startPoint);
					}
						
					}}
				System.out.println();
				display_table(seq);
				display_table_ordered(seq);
				}
	
public static void getMotif (String window, String seq,int windowStart) {
							
			int start,end, count,foundFlag,printFlag;
			count =1;
			foundFlag = 0;
			printFlag=0;
			
			
			for (start=windowStart+1;start<=seq.length()-window.length();++start){
				//the matching begins with the next character of the window, ie the first occurence of the motif
				
				end = start + (window.length());
							
				if(window.equals(seq.substring(start,end))){
					foundFlag=1;
					count++;
					
					if(foundFlag==1 && printFlag==0)
					{
						ResultSet id;
						try {
					        // STEP 2: Register JDBC driver
					        Class.forName("com.mysql.jdbc.Driver");

					        // STEP 3: Open a connection
					       // System.out.print("\nConnecting to database...");
					        conn = DriverManager.getConnection(DB_URL, USER, PASS);
					       // System.out.println(" SUCCESS!\n");

					       stmt = conn.createStatement();
					       String sql1="select dna_id from dna where Sequence='"+(seq)+"';";
					       id=stmt.executeQuery(sql1);
					       if(id.next()){
					      
					    	   String sql = "INSERT INTO motif (Motif_string,Position,Length_m,dna_id) values ('" +(window)+"','"+(windowStart+1)+"','"+(window.length())+"','"+(id.getInt("dna_id"))+"');";
					            
					    	   stmt.executeUpdate(sql);

					    	   //System.out.println(" SUCCESS!\n");
					       }

					   } 
						catch(SQLException se) {
					        se.printStackTrace();
					    } 
						catch(Exception e) {
					        e.printStackTrace();
					    } 
						finally {
					        try {
					            if(stmt != null)
					                conn.close();
					        } 
					        catch(SQLException se) {
					        }
					        try {
					            if(conn != null)
					                conn.close();
					        } 
					        catch(SQLException se) {
					            se.printStackTrace();
					        }
					    }
					    

						System.out.println("\n***************\nMotif: "+window);
						System.out.println("Motif Length: "+window.length());
						System.out.println("#1"+" occurence at position: "+(windowStart+1));
						printFlag=1;
					}
					
					
					
					System.out.println("#"+(count)+" occurence at position: "+(start+1));
									
				}
				
			}
			
			if (foundFlag ==1)
			{
			System.out.println("\nTotal occurences: "+(count));
			try{
				
			        // STEP 2: Register JDBC driver
			 Class.forName("com.mysql.jdbc.Driver");

			        // STEP 3: Open a connection
			 // System.out.print("\nConnecting to database...");
			  conn = DriverManager.getConnection(DB_URL, USER, PASS);
			  //System.out.println(" SUCCESS!\n");

			       stmt = conn.createStatement();
			String sql3="select dna_id from dna where Sequence='"+(seq)+"';";
		    ResultSet id1=stmt.executeQuery(sql3);
		    if(id1.next()){
		    String sql4="update motif set Occurence='"+(count)+"' where dna_id='"+(id1.getInt("dna_id"))+"';";
			stmt.executeUpdate(sql4);
			//System.out.println(" UPDATE SUCCESS!\n");
		    }
			}
			
			catch(SQLException se) {
		        se.printStackTrace();
		    } 
			catch(Exception e) {
		        e.printStackTrace();
		    } 
			finally {
		        try {
		            if(stmt != null)
		                conn.close();
		        } 
		        catch(SQLException se) {
		        }
		        try {
		            if(conn != null)
		                conn.close();
		        } 
		        catch(SQLException se) {
		            se.printStackTrace();
		        }
		    }
			}
		}

public void display_table(String seq){
ResultSet id;int did;
try
{
	Class.forName("com.mysql.jdbc.Driver");

    // STEP 3: Open a connection
    //System.out.print("\nConnecting to database...");
    conn = DriverManager.getConnection(DB_URL, USER, PASS);
    //System.out.println(" SUCCESS!\n");
    stmt1 = conn.createStatement();
    String sql11="select dna_id from dna where Sequence='"+(seq)+"';";
    id=stmt1.executeQuery(sql11);
    id.next();
    did=id.getInt("dna_id");

   stmt = conn.createStatement();
   String sql1="select * from motif where dna_id='"+(did)+"';";
   
   ResultSet id1=stmt.executeQuery(sql1);
   System.out.println("");
   System.out.println("=========================================================================");
   System.out.println("DNA_ID	|MOTIF		|POSITION	|LENGTH		|OCCURENCE	|");
   //System.out.println("_________________________________________________________________");
   System.out.println("=========================================================================");
  
  // iterate through the java resultset
  while (id1.next())
  {
    int id11 = id1.getInt("dna_id");
    String motif = id1.getString("Motif_string");
    int position = id1.getInt("Position");
    int length = id1.getInt("Length_m");
    int occurence = id1.getInt("Occurence");
    
    // print the results
    System.out.format("%s\t|\t%s\t|\t%s\t|\t%s\t|\t%s\t|\n", id11, motif, position, length, occurence);
  }
  System.out.println("=========================================================================");
 // st.close();
}
catch (Exception e)
{
  System.err.println("Got an exception! ");
  System.err.println(e.getMessage());
}
}


public void display_table_ordered(String seq){
	ResultSet id;int did;
	System.out.println("\n[TABLE ORDERED BY LENGTH DESCENDING]");

try
{
	Class.forName("com.mysql.jdbc.Driver");

    // STEP 3: Open a connection
   // System.out.print("\nConnecting to database...");
    conn = DriverManager.getConnection(DB_URL, USER, PASS);
   // System.out.println(" SUCCESS!\n");
    stmt1 = conn.createStatement();
    String sql11="select dna_id from dna where Sequence='"+(seq)+"';";
    id=stmt1.executeQuery(sql11);
    id.next();
    did=id.getInt("dna_id");

   stmt = conn.createStatement();
   String sqla="ALTER TABLE MOTIF ORDER BY LENGTH_M DESC;";
   stmt.executeUpdate(sqla);
   stmt2 = conn.createStatement();
   String sql1="select * from motif where dna_id='"+(did)+"';";
   ResultSet id1=stmt2.executeQuery(sql1);
   System.out.println("");
   System.out.println("=========================================================================");
   System.out.println("DNA_ID	|MOTIF		|POSITION	|LENGTH		|OCCURENCE	|");
   //System.out.println("_________________________________________________________________");
   System.out.println("=========================================================================");
  // iterate through the java resultset
  while (id1.next())
  {
    int id11 = id1.getInt("dna_id");
    String motif = id1.getString("Motif_string");
    int position = id1.getInt("Position");
    int length = id1.getInt("Length_m");
    int occurence = id1.getInt("Occurence");
    
    // print the results
    System.out.format("%s\t|\t%s\t|\t%s\t|\t%s\t|\t%s\t|\n", id11, motif, position, length, occurence);
  }
  System.out.println("=========================================================================");
 // st.close();
}
catch (Exception e)
{
  System.err.println("Got an exception! ");
  System.err.println(e.getMessage());
}
}
				
}