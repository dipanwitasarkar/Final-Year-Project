package motif_finder;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Mainclass {
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost:3306/nest_motifdb";

	// Database credentials
	static final String USER = "root";
	static final String PASS = "1234";

	static Connection conn = null;
	static Statement stmt = null;
	public static void main (String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		
		try
		{
			System.out.print("\nENTER THE SEQUENCE: ");
			String seq = scan.next();// the complete sequence
			Identify_motif nm=new Identify_motif();
			try {
		        // STEP 2: Register JDBC driver
		        Class.forName("com.mysql.jdbc.Driver");

		        // STEP 3: Open a connection
		        //System.out.print("\nConnecting to database...");
		        conn = DriverManager.getConnection(DB_URL, USER, PASS);
		        //System.out.println(" SUCCESS!\n");
		        stmt = conn.createStatement();
				String sql3="select dna_id from dna where Sequence='"+(seq)+"';";
			    ResultSet id1=stmt.executeQuery(sql3);
			    if(id1.next()){
			    int id=id1.getInt("dna_id");
			    if(id!=0){
			    	System.out.println("\n[THE SEQUENCE IS PRESENT IN DATABASE]");
			    	nm.display_table(seq);
			    nm.display_table_ordered(seq);
			    return;
			    }}
			    
			    }
			catch(SQLException se) {
		        se.printStackTrace();
		    } 
			catch(Exception e) {
		        e.printStackTrace();
		    } 
			finally {
		        try {
		            if(stmt != null)
		                conn.close();
		        } 
		        catch(SQLException se) {
		        }
		        try {
		            if(conn != null)
		                conn.close();
		        } 
		        catch(SQLException se) {
		            se.printStackTrace();
		        }}
			
			
		    	nm.Nested_motif(seq);
			
			}
		finally
		{
			scan.close();
		}
		
	}
}
	